/* ============================================
   RICCIONE CALCIO FAN CLUB - main.js
   ============================================ */

(function () {
  'use strict';

  /* ---- THEME ---- */
  function getStoredTheme() {
    return localStorage.getItem('rcfc-theme') || 'dark';
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const btn = document.getElementById('themeToggle');
    if (!btn) return;
    if (theme === 'dark') {
      btn.querySelector('.icon').textContent = '☀️';
      btn.querySelector('.label').textContent = 'Tema Chiaro';
    } else {
      btn.querySelector('.icon').textContent = '🌙';
      btn.querySelector('.label').textContent = 'Tema Scuro';
    }
  }

  function initTheme() {
    const theme = getStoredTheme();
    applyTheme(theme);
    const btn = document.getElementById('themeToggle');
    if (!btn) return;
    btn.addEventListener('click', function () {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      localStorage.setItem('rcfc-theme', next);
      applyTheme(next);
    });
  }

  /* ---- HAMBURGER ---- */
  function initHamburger() {
    const btn = document.getElementById('hamburger');
    const nav = document.getElementById('mainNav');
    if (!btn || !nav) return;

    btn.addEventListener('click', function () {
      btn.classList.toggle('open');
      nav.classList.toggle('open');
    });

    // Sub-menu tap on mobile
    document.querySelectorAll('.nav-item.has-sub > .nav-link').forEach(function (link) {
      link.addEventListener('click', function (e) {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          const parent = link.parentElement;
          parent.classList.toggle('open');
        }
      });
    });
  }

  /* ---- SOCIAL SHARE ---- */
  function initShare() {
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);

    document.querySelectorAll('.share-btn[data-share]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        let shareUrl = '';
        switch (btn.dataset.share) {
          case 'fb':
            shareUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + url;
            break;
          case 'tw':
            shareUrl = 'https://twitter.com/intent/tweet?url=' + url + '&text=' + title;
            break;
          case 'wa':
            shareUrl = 'https://wa.me/?text=' + title + '%20' + url;
            break;
          case 'tg':
            shareUrl = 'https://t.me/share/url?url=' + url + '&text=' + title;
            break;
        }
        if (shareUrl) window.open(shareUrl, '_blank', 'noopener,width=600,height=400');
      });
    });
  }

  /* ---- INIT ---- */
  document.addEventListener('DOMContentLoaded', function () {
    initTheme();
    initHamburger();
    initShare();
  });
})();
