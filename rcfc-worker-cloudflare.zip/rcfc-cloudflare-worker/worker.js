/**
 * Riccione Calcio Fan Club - Cloudflare Worker
 * Serve file statici con routing SPA e headers di sicurezza
 */

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    let pathname = url.pathname;

    // Rimuovi trailing slash tranne per la root
    if (pathname !== "/" && pathname.endsWith("/")) {
      pathname = pathname.slice(0, -1);
    }

    // Routing: mappa i path ai file statici
    const routeMap = {
      "/":                    "index.html",
      "/index.html":          "index.html",
      "/style.css":           "style.css",
      "/main.js":             "main.js",
      "/meteo":               "meteo/index.html",
      "/meteo/index.html":    "meteo/index.html",
      "/serie-c-femminile":         "serie-c-femminile/index.html",
      "/serie-c-femminile/index.html": "serie-c-femminile/index.html",
      "/coppa-emilia":              "coppa-emilia/index.html",
      "/coppa-emilia/index.html":   "coppa-emilia/index.html",
      "/coppa-serie-c":             "coppa-serie-c/index.html",
      "/coppa-serie-c/index.html":  "coppa-serie-c/index.html",
      "/coppa-italia":              "coppa-italia/index.html",
      "/coppa-italia/index.html":   "coppa-italia/index.html",
      "/seconda-categoria":         "seconda-categoria/index.html",
      "/seconda-categoria/index.html": "seconda-categoria/index.html",
      "/promozione":                "promozione/index.html",
      "/promozione/index.html":     "promozione/index.html",
      "/viaggi":                    "viaggi/index.html",
      "/viaggi/index.html":         "viaggi/index.html",
    };

    const assetKey = routeMap[pathname];

    // Se il path non è mappato, restituisci la homepage (SPA fallback)
    const fileKey = assetKey || "index.html";

    // Recupera il file da KV Assets (Workers Sites)
    let asset;
    try {
      asset = await env.__STATIC_CONTENT.get(fileKey, { type: "arrayBuffer" });
    } catch (e) {
      // fallback index
      asset = await env.__STATIC_CONTENT.get("index.html", { type: "arrayBuffer" });
    }

    if (!asset) {
      return new Response("Not Found", { status: 404 });
    }

    // Determina Content-Type
    const contentType = getContentType(fileKey);

    // Headers di sicurezza (come nel file _headers originale) + cache
    const headers = {
      "Content-Type": contentType,
      "X-Frame-Options": "SAMEORIGIN",
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": fileKey.endsWith(".html")
        ? "public, max-age=300"          // HTML: 5 minuti
        : "public, max-age=86400",        // CSS/JS: 1 giorno
    };

    return new Response(asset, { status: 200, headers });
  },
};

function getContentType(filename) {
  if (filename.endsWith(".html")) return "text/html; charset=utf-8";
  if (filename.endsWith(".css"))  return "text/css; charset=utf-8";
  if (filename.endsWith(".js"))   return "application/javascript; charset=utf-8";
  if (filename.endsWith(".json")) return "application/json";
  if (filename.endsWith(".png"))  return "image/png";
  if (filename.endsWith(".jpg") || filename.endsWith(".jpeg")) return "image/jpeg";
  if (filename.endsWith(".svg"))  return "image/svg+xml";
  if (filename.endsWith(".ico"))  return "image/x-icon";
  return "text/plain";
}
